-- AlterTable
ALTER TABLE "Pegawai" ALTER COLUMN "tanggal_lahir" SET DATA TYPE DATE;
