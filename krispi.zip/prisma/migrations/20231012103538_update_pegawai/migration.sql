-- AlterTable
ALTER TABLE "Pegawai" ALTER COLUMN "alamat" DROP NOT NULL,
ALTER COLUMN "kontur_wajah" DROP NOT NULL;
