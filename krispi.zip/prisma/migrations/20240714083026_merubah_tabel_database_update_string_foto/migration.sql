-- AlterTable
ALTER TABLE "Penduduk" ALTER COLUMN "foto" DROP NOT NULL;
